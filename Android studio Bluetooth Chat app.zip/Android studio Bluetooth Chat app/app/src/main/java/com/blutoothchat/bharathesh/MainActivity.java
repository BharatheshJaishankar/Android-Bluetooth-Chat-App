package com.blutoothchat.bharathesh;

import android.app.Activity;
import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.content.*;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.webkit.*;
import android.animation.*;
import android.view.animation.*;
import java.util.*;
import java.util.regex.*;
import java.text.*;
import org.json.*;
import java.util.HashMap;
import java.util.ArrayList;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.TextView;
import android.widget.Switch;
import android.widget.Spinner;
import android.widget.EditText;
import android.widget.ImageView;
import java.util.Timer;
import java.util.TimerTask;
import android.widget.CompoundButton;
import android.widget.AdapterView;
import android.view.View;
import android.graphics.Typeface;
import android.app.Fragment;
import android.app.FragmentManager;
import android.app.DialogFragment;


public class MainActivity extends  Activity { 
	
	private Timer _timer = new Timer();
	
	private double variable = 0;
	private HashMap<String, Object> ne = new HashMap<>();
	private String Imagepath = "";
	private String ImageName = "";
	private String time = "";
	private double indicate = 0;
	
	private ArrayList<HashMap<String, Object>> all_data = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> connected_bt = new ArrayList<>();
	private ArrayList<String> bt_name = new ArrayList<>();
	private ArrayList<String> bt_address = new ArrayList<>();
	private ArrayList<String> listview_only = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> map_blue_mess = new ArrayList<>();
	
	private LinearLayout linear1;
	private LinearLayout linear3;
	private LinearLayout linear2;
	private ListView listview1;
	private LinearLayout linear4;
	private TextView textview2;
	private Switch switch1;
	private TextView textview1;
	private Spinner spinner1;
	private EditText edittext1;
	private ImageView imageview1;
	
	private BluetoothConnect bt;
	private BluetoothConnect.BluetoothConnectionListener _bt_bluetooth_connection_listener;
	private TimerTask t;
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.main);
		initialize(_savedInstanceState);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		
		linear1 = (LinearLayout) findViewById(R.id.linear1);
		linear3 = (LinearLayout) findViewById(R.id.linear3);
		linear2 = (LinearLayout) findViewById(R.id.linear2);
		listview1 = (ListView) findViewById(R.id.listview1);
		linear4 = (LinearLayout) findViewById(R.id.linear4);
		textview2 = (TextView) findViewById(R.id.textview2);
		switch1 = (Switch) findViewById(R.id.switch1);
		textview1 = (TextView) findViewById(R.id.textview1);
		spinner1 = (Spinner) findViewById(R.id.spinner1);
		edittext1 = (EditText) findViewById(R.id.edittext1);
		imageview1 = (ImageView) findViewById(R.id.imageview1);
		bt = new BluetoothConnect(this);
		
		switch1.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
			@Override
			public void onCheckedChanged(CompoundButton _param1, boolean _param2)  {
				final boolean _isChecked = _param2;
				if (_isChecked) {
					bt.activateBluetooth();
					bt.readyConnection(_bt_bluetooth_connection_listener, "Bluetooth");
					_Get_paired_devices();
				}
				else {
					android.bluetooth.BluetoothAdapter adapter = android.bluetooth.BluetoothAdapter.getDefaultAdapter();
					adapter.disable();
					bt.readyConnection(_bt_bluetooth_connection_listener, "Bluetooth");
				}
			}
		});
		
		spinner1.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
			@Override
			public void onItemSelected(AdapterView<?> _param1, View _param2, int _param3, long _param4) {
				final int _position = _param3;
				if (_position > 0) {
					bt.startConnection(_bt_bluetooth_connection_listener, bt_address.get((int)(_position)), "Bluetooth");
				}
			}
			
			@Override
			public void onNothingSelected(AdapterView<?> _param1) {
				
			}
		});
		
		imageview1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (edittext1.getText().toString().equals("")) {
					SketchwareUtil.showMessage(getApplicationContext(), "enter message");
				}
				else {
					bt.sendData(_bt_bluetooth_connection_listener, edittext1.getText().toString(), "Bluetooth");
					edittext1.setText("");
				}
			}
		});
		
		_bt_bluetooth_connection_listener = new BluetoothConnect.BluetoothConnectionListener() {
			@Override
			public void onConnected(String _param1, HashMap<String, Object> _param2) {
				final String _tag = _param1;
				final HashMap<String, Object> _deviceData = _param2;
				connected_bt.clear();
				connected_bt.add(_deviceData);
				spinner1.setVisibility(View.GONE);
				textview1.setVisibility(View.VISIBLE);
				textview1.setText(connected_bt.get((int)0).get("name").toString());
				SketchwareUtil.showMessage(getApplicationContext(), "connected");
			}
			
			@Override
			public void onDataReceived(String _param1, byte[] _param2, int _param3) {
				final String _tag = _param1;
				final String _data = new String(_param2, 0, _param3);
				{
					HashMap<String, Object> _item = new HashMap<>();
					_item.put("a", _data);
					map_blue_mess.add(_item);
				}
				
				listview1.setAdapter(new Listview1Adapter(map_blue_mess));
				((BaseAdapter)listview1.getAdapter()).notifyDataSetChanged();
			}
			
			@Override
			public void onDataSent(String _param1, byte[] _param2) {
				final String _tag = _param1;
				final String _data = new String(_param2);
				{
					HashMap<String, Object> _item = new HashMap<>();
					_item.put("a", _data);
					map_blue_mess.add(_item);
				}
				
				listview1.setAdapter(new Listview1Adapter(map_blue_mess));
				((BaseAdapter)listview1.getAdapter()).notifyDataSetChanged();
			}
			
			@Override
			public void onConnectionError(String _param1, String _param2, String _param3) {
				final String _tag = _param1;
				final String _connectionState = _param2;
				final String _errorMessage = _param3;
				SketchwareUtil.showMessage(getApplicationContext(), _errorMessage);
				spinner1.setVisibility(View.VISIBLE);
				textview1.setVisibility(View.GONE);
			}
			
			@Override
			public void onConnectionStopped(String _param1) {
				final String _tag = _param1;
				SketchwareUtil.showMessage(getApplicationContext(), _tag.concat(" stopped"));
				spinner1.setVisibility(View.VISIBLE);
				textview1.setVisibility(View.GONE);
			}
		};
	}
	
	private void initializeLogic() {
		bt_name.add("choose device");
		spinner1.setAdapter(new ArrayAdapter<String>(getBaseContext(), android.R.layout.simple_spinner_dropdown_item, bt_name));
		textview1.setVisibility(View.GONE);
		if (bt.isBluetoothActivated()) {
			bt.readyConnection(_bt_bluetooth_connection_listener, "Bluetooth");
			switch1.setEnabled(true);
		}
		linear2.setElevation((float)50);
		linear2.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c) { this.setStroke(a, b); this.setColor(c); return this; } }.getIns((int)5, 0xFF9E9E9E, 0xFFDBC1E3));
		textview1.setTextColor(0xFFFFFFFF);
		textview2.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/lato.ttf"), 1);
		linear2.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)100, 0xFFDBC1E3));
	}
	
	@Override
	protected void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		
		super.onActivityResult(_requestCode, _resultCode, _data);
		
		switch (_requestCode) {
			
			default:
			break;
		}
	}
	
	private void _Get_paired_devices () {
		all_data.clear();
		bt_name.clear();
		bt_address.clear();
		bt_name.add("choose device");
		bt_address.add("none");
		t = new TimerTask() {
			@Override
			public void run() {
				runOnUiThread(new Runnable() {
					@Override
					public void run() {
						if (bt.isBluetoothActivated()) {
							bt.getPairedDevices(all_data);
							variable = 0;
							for(int _repeat42 = 0; _repeat42 < (int)(all_data.size()); _repeat42++) {
								bt_name.add(all_data.get((int)variable).get("name").toString());
								bt_address.add(all_data.get((int)variable).get("address").toString());
								variable++;
								spinner1.setAdapter(new ArrayAdapter<String>(getBaseContext(), android.R.layout.simple_spinner_dropdown_item, bt_name));
								((ArrayAdapter)spinner1.getAdapter()).notifyDataSetChanged();
								t.cancel();
							}
						}
						else {
							
						}
					}
				});
			}
		};
		_timer.scheduleAtFixedRate(t, (int)(0), (int)(2000));
	}
	
	
	private void _radius_4 (final String _color1, final String _color2, final double _str, final double _n1, final double _n2, final double _n3, final double _n4, final View _view) {
		android.graphics.drawable.GradientDrawable gd = new android.graphics.drawable.GradientDrawable();
		
		gd.setColor(Color.parseColor(_color1));
		
		gd.setStroke((int)_str, Color.parseColor(_color2));
		
		gd.setCornerRadii(new float[]{(int)_n1,(int)_n1,(int)_n2,(int)_n2,(int)_n3,(int)_n3,(int)_n4,(int)_n4});
		
		_view.setBackground(gd);
	}
	
	
	public class Listview1Adapter extends BaseAdapter {
		ArrayList<HashMap<String, Object>> _data;
		public Listview1Adapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public int getCount() {
			return _data.size();
		}
		
		@Override
		public HashMap<String, Object> getItem(int _index) {
			return _data.get(_index);
		}
		
		@Override
		public long getItemId(int _index) {
			return _index;
		}
		@Override
		public View getView(final int _position, View _v, ViewGroup _container) {
			LayoutInflater _inflater = (LayoutInflater)getBaseContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
			View _view = _v;
			if (_view == null) {
				_view = _inflater.inflate(R.layout.custom, null);
			}
			
			final LinearLayout linear1 = (LinearLayout) _view.findViewById(R.id.linear1);
			final LinearLayout linear2 = (LinearLayout) _view.findViewById(R.id.linear2);
			final TextView textview2 = (TextView) _view.findViewById(R.id.textview2);
			
			textview2.setText(map_blue_mess.get((int)_position).get("a").toString());
			linear2.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)100, 0xFFDCEDC8));
			linear1.setGravity(Gravity.RIGHT);
			_radius_4("#E0E0E0", "#1565C0", 8, 25, 25, 0, 25, linear2);
			
			return _view;
		}
	}
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input){
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels(){
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels(){
		return getResources().getDisplayMetrics().heightPixels;
	}
	
}
